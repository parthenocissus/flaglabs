<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="fr">
<context>
    <name>Ms::MuseScore</name>
    <message>
        <location filename="../batch_convert.qml" line="81"/>
        <location filename="../batch_convert.qml" line="91"/>
        <location filename="../batch_convert.qml" line="98"/>
        <source>MuseScore Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="108"/>
        <location filename="../batch_convert.qml" line="120"/>
        <location filename="../batch_convert.qml" line="130"/>
        <source>MusicXML Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="140"/>
        <location filename="../batch_convert.qml" line="150"/>
        <location filename="../batch_convert.qml" line="155"/>
        <source>MIDI Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="177"/>
        <location filename="../batch_convert.qml" line="182"/>
        <source>Capella Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="209"/>
        <location filename="../batch_convert.qml" line="214"/>
        <source>Bagpipe Music Writer Files (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="187"/>
        <location filename="../batch_convert.qml" line="192"/>
        <source>BB Files (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="160"/>
        <source>MuseData Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="172"/>
        <source>Optical Music Recognition</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="197"/>
        <location filename="../batch_convert.qml" line="202"/>
        <source>Overture / Score Writer Files (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="219"/>
        <location filename="../batch_convert.qml" line="224"/>
        <location filename="../batch_convert.qml" line="229"/>
        <location filename="../batch_convert.qml" line="234"/>
        <location filename="../batch_convert.qml" line="239"/>
        <location filename="../batch_convert.qml" line="246"/>
        <source>Guitar Pro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="253"/>
        <source>Power Tab Editor Files (experimental)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="260"/>
        <location filename="../batch_convert.qml" line="267"/>
        <source>MuseScore Backup Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="292"/>
        <source>MuseScore 3 File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="302"/>
        <source>Uncompressed MuseScore 3 File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="315"/>
        <source>Uncompressed MusicXML File (outdated)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="328"/>
        <source>Uncompressed MusicXML File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="338"/>
        <source>Compressed MusicXML File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="348"/>
        <location filename="../batch_convert.qml" line="360"/>
        <source>Standard MIDI File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="371"/>
        <source>PDF File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="378"/>
        <source>PostStript File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="383"/>
        <source>PNG Bitmap Graphic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="388"/>
        <source>Scalable Vector Graphics</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="395"/>
        <source>LilyPond Format</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="400"/>
        <source>Wave Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="405"/>
        <source>FLAC Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="410"/>
        <source>Ogg Vorbis Audio</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="415"/>
        <source>MP3 Audio</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QPlatformTheme</name>
    <message>
        <location filename="../batch_convert.qml" line="464"/>
        <source>Restore Defaults</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="475"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="484"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QWizzard</name>
    <message>
        <location filename="../batch_convert.qml" line="831"/>
        <location filename="../batch_convert.qml" line="980"/>
        <source>Done</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>action</name>
    <message>
        <location filename="../batch_convert.qml" line="446"/>
        <source>Export parts</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>batch_convert</name>
    <message>
        <location filename="../batch_convert.qml" line="13"/>
        <source>Batch Convert</source>
        <translation>Conversion par lots</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="16"/>
        <source>This plugin converts multiple files from various formats into various formats</source>
        <translation>Ce plugin convertit plusieurs fichiers de différents formats en d&apos;autres formats</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="23"/>
        <source>Unsupported MuseScore Version</source>
        <translation>Cette version de MuseScore n&apos;est pas prise en charge</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="24"/>
        <source>This plugin needs MuseScore 3</source>
        <translation>Ce plugin ne fonctionne qu&apos;avec MuseScore 3</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="65"/>
        <source>Input Formats</source>
        <translation>Formats d&apos;entrée</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="280"/>
        <source>Output Formats</source>
        <translation>Formats de sortie</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="422"/>
        <source>Positions of measures (XML)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="429"/>
        <source>Positions of segments (XML)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="434"/>
        <source>Internal file sanity check log (JSON)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="439"/>
        <source>Metadata JSON</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="452"/>
        <source>Process
Subdirectories</source>
        <translation>Traite les
sous-dossiers</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="460"/>
        <source>Different Export
Path</source>
        <translation>Chemin d&apos;export
différent</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="559"/>
        <source>Select Sources Startfolder</source>
        <translation>Sélectionner le dossier source de départ</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="560"/>
        <source>Select Sources Folder</source>
        <translation>Sélectionner le dossier source</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="582"/>
        <source>Select Target Folder</source>
        <translation>Sélectionner le dossier de destination</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="698"/>
        <source>Running...</source>
        <translation>En cours...</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="802"/>
        <location filename="../batch_convert.qml" line="868"/>
        <source>Error: %1 → %2 not exported</source>
        <translation>Erreur : %1 → %2 n&apos;est pas exporté</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="805"/>
        <location filename="../batch_convert.qml" line="871"/>
        <source>%1 is up to date</source>
        <translation>%1 est convertit</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="893"/>
        <source>ERROR reading file %1</source>
        <translation>ERREUR de lecture du fichier %1</translation>
    </message>
    <message>
        <location filename="../batch_convert.qml" line="978"/>
        <source>No files found</source>
        <translation>Aucuns fichier trouvé</translation>
    </message>
</context>
</TS>
